import { Component } from '@angular/core';

@Component({
  selector: 'app-tab-3',
  template: `
    <div>Content from a component</div>
  `
})
export class Tab3Component {}