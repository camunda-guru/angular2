/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { Component, OnChange } from '@angular/core';

@Component({
    selector: 'calculate-interest',
    templateUrl: 'events/event.interestComponent.html'
})
export class InterestComponent implements OnChange {
    principal = 10000;
    roi=0.08;
    years=4;
    simpleInterest = 0;

    ngOnChange(principal: number,roi:number,years:number) {
        console.log(principal);

        this.simpleInterest = (this.principal*this.years*this.roi);
        //this.num=val+10;
    }
}
