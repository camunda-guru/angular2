"use strict";
/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var event_module_1 = require('./event.module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(event_module_1.AppModule);
//# sourceMappingURL=main.js.map