/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'visitor-counter',
    templateUrl: 'events/visitor.component.html'
})
export class CounterComponent {
    @Input()  count = 0;
    @Output() result = new EventEmitter<number>();

    increment() {
        this.count++;
        this.result.emit(this.count);
    }
}
